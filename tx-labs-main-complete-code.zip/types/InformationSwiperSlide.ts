type InformationSwiperSlide = {
  title: string;
  body: string;
};

export default InformationSwiperSlide;
