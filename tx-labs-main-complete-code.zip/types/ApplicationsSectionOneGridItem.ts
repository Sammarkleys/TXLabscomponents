import type Icon from './Icon';

type ApplicationsSectionOneGridItem = {
  icon: Icon;
  title: string;
};

export default ApplicationsSectionOneGridItem;
