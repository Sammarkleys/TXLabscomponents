type RoadmapSectionSwiperSlide = {
  imgSrc: string;
  title: string;
  listItems: string[];
};

export default RoadmapSectionSwiperSlide;
