type TechnicalStructureSectionGridItem = {
  title: string;
  body: string;
};

export default TechnicalStructureSectionGridItem;
