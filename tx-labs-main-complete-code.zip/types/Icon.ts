type Icon =
  | 'bridges'
  | 'close'
  | 'computations'
  | 'discord'
  | 'file'
  | 'github'
  | 'medium'
  | 'more'
  | 'open'
  | 'oracles'
  | 'roadmap-four'
  | 'roadmap-one'
  | 'roadmap-three'
  | 'roadmap-two'
  | 'roll-ups'
  | 'storage'
  | 'telegram'
  | 'twitter'
  | 'user';

export default Icon;
