import React, { useCallback, useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame, useThree } from 'react-three-fiber'
import * as THREE from 'three'


var SEPARATION = 100,
AMOUNTX = 100,
AMOUNTY = 70;
var count = 0;

function Dots(props) {
  const ref = useRef()
  const { particles } = useMemo(() => {
    var particles = [];
    var i = 0;
    for (var ix = 0; ix < props.amountx; ix++) {
        for (var iy = 0; iy < props.amounty; iy++) {
          const particle = new THREE.Sprite()
          particle.position.x = ix * props.seperation - ((props.amountx * props.seperation) / 2);
          particle.position.z = iy * props.seperation - ((props.amounty * props.seperation) / 2);
          particles.push(particle);
        }
    }
    return { particles }
  }, [])

  useFrame(({ clock }) => {

    let i=0;
    for (var ix = 0; ix < props.amountx; ix++) {
      for (var iy = 0; iy < props.amounty; iy++) {
        let particle =  particles[i++];
        particle.position.y = (Math.sin((ix + count) * 0.3) * 50) + (Math.sin((iy + count) * 0.5) * 50);
        particle.scale.x = particle.scale.y = (Math.sin((ix + count) * 0.3) + 1) * 2 + (Math.sin((iy + count) * 0.5) + 1) * 2;
        let transformation = new THREE.Matrix4();
        transformation.makeTranslation(particle.position.x, particle.position.y, particle.position.z);
        ref.current.setMatrixAt(i, transformation)
      }
    }
    ref.current.instanceMatrix.needsUpdate = true
    count += 0.1;
  })

  return (
    <instancedMesh ref={ref} args={[null, null, props.amountx*props.amounty]}>
      <circleBufferGeometry args={[props.size]} />
      <meshBasicMaterial color={"#fff"}/>
    </instancedMesh>
  )
}



export default function ParticleCanvas(props) {
  return (
    <Canvas className="left-0 right-0 opacity-100"
    style={{...props.style}}
    camera={{ fov: 120, position: props.position, near:-20, far:1000 }}
    >
      <color attach="background" args={[0,0,0]} />
      <Dots  {...props} />
    </Canvas>
  )
}


