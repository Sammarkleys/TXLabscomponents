import type { NavigationItem } from 'types';

type FooterNavigationItemProps = {
  item: NavigationItem;
};

export default FooterNavigationItemProps;
