import type FooterNavigationItemProps from './FooterNavigationItemProps';
import Icon from '../Icon';

const FooterNavigationItem = ({ item }: FooterNavigationItemProps) => (
  <li className="space-y-6">
    <h3 className="text-[1.375rem]">{item.title}</h3>
    <ul className="space-y-4">
      {item.children.map((child) => (
        <li key={child.title}>
          <a className="flex items-center gap-5" href={child.href}>
            <Icon icon={child.icon} />
            <span className="text-lg font-display">{child.title}</span>
          </a>
        </li>
      ))}
    </ul>
  </li>
);

export default FooterNavigationItem;
