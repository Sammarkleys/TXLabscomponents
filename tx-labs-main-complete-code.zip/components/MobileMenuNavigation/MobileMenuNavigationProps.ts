import type { NavigationItem } from 'types';

type MobileMenuNavigationProps = {
  items: NavigationItem[];
};

export default MobileMenuNavigationProps;
