import type { Icon } from 'types';

type IconProps = {
  icon: Icon;
};

export default IconProps;
