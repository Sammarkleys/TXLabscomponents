import type FooterNavigationProps from './FooterNavigationProps';
import FooterNavigationItem from '../FooterNavigationItem';

const FooterNavigation = ({ items }: FooterNavigationProps) => (
  <ul className="flex flex-wrap items-start gap-16 space-between">
    {items.map((item) => (
      <FooterNavigationItem key={item.title} item={item} />
    ))}
  </ul>
);

export default FooterNavigation;
