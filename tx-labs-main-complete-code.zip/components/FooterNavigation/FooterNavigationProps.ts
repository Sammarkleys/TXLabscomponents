import type { NavigationItem } from 'types';

type FooterNavigationProps = {
  items: NavigationItem[];
};

export default FooterNavigationProps;
