import type { ApplicationsSectionOneGridItem } from 'types';

type ApplicationsSectionOneGridItemProps = {
  item: ApplicationsSectionOneGridItem;
};

export default ApplicationsSectionOneGridItemProps;
