import { Dialog } from '@headlessui/react';
import type MobileMenuModalProps from './MobileMenuModalProps';
import MobileMenuNavigation from '../MobileMenuNavigation';
import MeshLogo from '../MeshLogo';

const MobileMenuModal = ({
  open,
  onClose,
  navigationItems,
}: MobileMenuModalProps) => (
  <Dialog
    open={open}
    onClose={onClose}
    className="fixed bottom-0 left-0 right-0 z-10 overflow-y-auto bg-black top-[4.25rem]"
  >
    <div className="container py-12 space-y-12">
      <MobileMenuNavigation items={navigationItems} />
      <div className="flex flex-col items-center gap-4">
        <MeshLogo />
        <p>&copy; Copyright TX Labs &middot; All rights reserved</p>
      </div>
    </div>
  </Dialog>
);

export default MobileMenuModal;
