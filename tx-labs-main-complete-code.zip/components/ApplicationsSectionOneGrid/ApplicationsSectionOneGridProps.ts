import type { ApplicationsSectionOneGridItem } from 'types';

type ApplicationsSectionOneGridProps = {
  items: ApplicationsSectionOneGridItem[];
};

export default ApplicationsSectionOneGridProps;
