import classNames from 'classnames';
import SectionProps from './SectionProps';

const Section = ({ className, children }: SectionProps) => (
  <section className={classNames('py-20 overflow-hidden', className)}>
    {children}
  </section>
);

export default Section;
