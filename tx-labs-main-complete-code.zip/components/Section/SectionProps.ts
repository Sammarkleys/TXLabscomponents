import type { ReactNode } from 'react';

type SectionProps = {
  className?: string;
  children: ReactNode;
};

export default SectionProps;
