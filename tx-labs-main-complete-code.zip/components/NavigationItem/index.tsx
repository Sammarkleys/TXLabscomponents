import { Menu } from '@headlessui/react';
import { IoChevronDownOutline } from 'react-icons/io5';
import classNames from 'classnames';
import type NavigationItemProps from './NavigationItemProps';
import Icon from '../Icon';

const NavigationItem = ({ item }: NavigationItemProps) => (
  <li className="relative">
    <Menu>
      <Menu.Button className="flex items-center gap-1">
        <span className="text-lg font-display">{item.title}</span>
        <IoChevronDownOutline size={20} />
      </Menu.Button>
      <Menu.Items
        className="absolute left-0 p-6 space-y-4 bg-black border border-[#2c2c2c] rounded-lg top-[3.6875rem] bg-gradient-to-t from-[#1d0040] to-[#0c0c0c]"
        as="ul"
      >
        <div className="absolute w-6 h-6 bg-[#0c0c0c] rounded-full -top-2 left-8" />
        {item.children.map((child, index) => (
          <Menu.Item
            className={classNames({
              '!mt-0': index === 0,
            })}
            as="li"
            key={child.title}
          >
            {() => (
              <a className="flex items-center gap-4" href={child.href}>
                <Icon icon={child.icon} />
                <span className="text-lg font-display">{child.title}</span>
              </a>
            )}
          </Menu.Item>
        ))}
      </Menu.Items>
    </Menu>
  </li>
);

export default NavigationItem;
