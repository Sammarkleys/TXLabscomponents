import type { NavigationItem } from 'types';

type NavigationItemProps = {
  item: NavigationItem;
};

export default NavigationItemProps;
