// @ts-ignore
import Fade from 'react-reveal/Fade';
import Link from 'next/link';
import MailchimpSubscribe from 'react-mailchimp-subscribe';
import Section from '../Section';

const NewsletterSection = () => (
  <Section>
    <Fade>
      <div className="container flex flex-col items-center justify-center gap-4 lg:flex-row">
        <div>
          <h2 className="text-xl">Sign up for our latest news</h2>
          <p>
            <span className="text-gray-400">Unsubscribe at any time.</span>{' '}
            <Link href="/privacy-policy">
              <a>Privacy policy</a>
            </Link>
          </p>
        </div>
        <MailchimpSubscribe
          url="https://txlabs.us20.list-manage.com/subscribe/post?u=a711fae0e3e98a0d293d02bfa&amp;id=1a17c3febe"
          render={() => (
            <div className="mailchimp-subscribe-form">
              <MailchimpSubscribe url="https://txlabs.us20.list-manage.com/subscribe/post?u=a711fae0e3e98a0d293d02bfa&amp;id=1a17c3febe" />
            </div>
          )}
        />
      </div>
    </Fade>
  </Section>
);

export default NewsletterSection;
