/* eslint-disable @next/next/no-img-element */
// @ts-ignore
import Fade from 'react-reveal/Fade';
import Section from '../Section';
import TwoColContainer from '../TwoColContainer';
import ApplicationsSectionOneGrid from '../ApplicationsSectionOneGrid';

const ApplicationsSectionOne = () => (
  <Section className="bg-center bg-no-repeat bg-cover lg:bg-contain bg-gradient">
    <TwoColContainer>
      <div>
        <Fade>
          <h2 className="max-w-xl text-[2.5rem]">
            Off-chain applications will help drive the next stage of growth in
            the crypto industry.
          </h2>
        </Fade>
        <img
          className="hidden lg:block lg:relative lg:-left-64"
          src="/svg/applications-section-one-illustration.svg"
          alt="Applications section one illustration"
        />
      </div>
      <Fade delay={200}>
        <ApplicationsSectionOneGrid
          items={[
            {
              icon: 'oracles',
              title: 'Oracles',
            },
            {
              icon: 'bridges',
              title: 'Bridges',
            },
            {
              icon: 'roll-ups',
              title: 'Roll-ups',
            },
            {
              icon: 'storage',
              title: 'Storage',
            },
            {
              icon: 'computations',
              title: 'Computations',
            },
            {
              icon: 'more',
              title: 'More...',
            },
          ]}
        />
      </Fade>
      <img
        className="block lg:hidden"
        src="/svg/applications-section-one-illustration.svg"
        alt="Applications section one illustration"
      />
    </TwoColContainer>
  </Section>
);

export default ApplicationsSectionOne;
