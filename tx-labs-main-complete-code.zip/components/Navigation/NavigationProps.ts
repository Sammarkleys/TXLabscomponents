import type { NavigationItem } from 'types';

type NavigationProps = {
  items: NavigationItem[];
};

export default NavigationProps;
