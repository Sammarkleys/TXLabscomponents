import type LayoutProps from './LayoutProps';
import Header from '../Header';
import Footer from '../Footer';

const Layout = ({ children }: LayoutProps) => (
  <>
    <Header />
    <main className="pt-[5.5625rem]">{children}</main>
    <Footer />
  </>
);

export default Layout;
