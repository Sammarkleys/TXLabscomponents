import type { InformationSwiperSlide } from 'types';

type InformationSwiperProps = {
  slides: InformationSwiperSlide[];
};

export default InformationSwiperProps;
