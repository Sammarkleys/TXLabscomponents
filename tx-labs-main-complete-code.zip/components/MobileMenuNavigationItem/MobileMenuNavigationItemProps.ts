import type { NavigationItem } from 'types';

type MobileMenuNavigationItemProps = {
  item: NavigationItem;
};

export default MobileMenuNavigationItemProps;
