import type { ReactNode } from 'react';

type TwoColContainer = {
  children: ReactNode;
};

export default TwoColContainer;
