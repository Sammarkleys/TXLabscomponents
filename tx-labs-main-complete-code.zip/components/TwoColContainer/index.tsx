import type TwoColContainerProps from './TwoColContainer';

const TwoColContainer = ({ children }: TwoColContainerProps) => (
  <div className="container grid items-start grid-cols-1 gap-8 lg:grid-cols-2">
    {children}
  </div>
);

export default TwoColContainer;
