/* eslint-disable @next/next/no-img-element */
// @ts-ignore
import Fade from 'react-reveal/Fade';
import Section from '../Section';
import TwoColContainer from '../TwoColContainer';
import TechnicalStructureSectionGrid from '../TechnicalStructureSectionGrid';

const TechnicalStructureSection = () => (
  <Section>
    <div className="container hidden lg:block">
      <Fade>
        <img
          className="w-full h-auto"
          src="/png/tech-structure-section-illustration.png"
          alt=" Tech structure section illustration"
        />
      </Fade>
    </div>
    <div className="lg:hidden">
      <TwoColContainer>
        <Fade>
          <img
            className="w-full h-auto"
            src="/png/tech-structure-section-illustration-mobile.png"
            alt="Technical structure section illustration"
          />
        </Fade>
        <Fade delay={200}>
          <TechnicalStructureSectionGrid
            items={[
              {
                title: 'Modular plug-and-play design',
                body: 'Official tool kits for an easy development experience including pluggable BFT, on-chain identity modules and more.',
              },
              {
                title: 'Service framework',
                body: 'Robust framework that supports a wide range of service logic.',
              },
              {
                title: 'General-purpose node communication protocol',
                body: 'P2P network that features local consensus and facilitates both data and service based transactions.',
              },
              {
                title: 'Flexible hardware specifications',
                body: 'TX Mesh network supports a wide range of hardware specifications. The likes of Raspberry Pi are sufficient.',
              },
            ]}
          />
        </Fade>
      </TwoColContainer>
    </div>
  </Section>
);

export default TechnicalStructureSection;
