// @ts-ignore
import Fade from 'react-reveal/Fade';
import Section from '../Section';
import RoadmapSectionSwiper from '../RoadmapSectionSwiper';

const RoadmapSection = () => (
  <Section className="bg-center bg-no-repeat bg-cover lg:bg-contain bg-gradient">
    <div className="container space-y-6">
      <div className="pb-4 space-y-4 border-b roadmap-section-header">
        <Fade>
          <h2 className="text-[2.75rem] leading-none text-center lg:text-[5rem]">
            Roadmap
          </h2>
          <p className="text-xl font-black text-center font-display">2022</p>
        </Fade>
      </div>
      <Fade delay={200}>
        <RoadmapSectionSwiper
          slides={[
            {
              imgSrc: '/svg/roadmap-one.svg',
              title: 'Q1',
              listItems: [
                'TX Mesh MVP',
                'TX Mesh industry partnerships & collaborations',
                'Conclusion of the seed round fundraising',
              ],
            },
            {
              imgSrc: '/svg/roadmap-two.svg',
              title: 'Q2',
              listItems: [
                'TX Mesh private alpha',
                'Development of TX Mesh SDK and TX Mesh tool kits',
              ],
            },
            {
              imgSrc: '/svg/roadmap-three.svg',
              title: 'Q3',
              listItems: [
                'TX Mesh public beta',
                'Launch of partnership campaigns to attract developers to build on TX Mesh',
              ],
            },
            {
              imgSrc: '/svg/roadmap-four.svg',
              title: 'Q4',
              listItems: [
                'Launch of TX Mesh',
                'TX Token distribution',
                'Launch of TX Mesh development grants',
              ],
            },
          ]}
        />
      </Fade>
    </div>
  </Section>
);

export default RoadmapSection;
