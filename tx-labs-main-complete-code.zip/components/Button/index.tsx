import type ButtonProps from './ButtonProps';

const Button = ({ href, children }: ButtonProps) => (
  <a className="button" href={href}>
    {children}
  </a>
);

export default Button;
