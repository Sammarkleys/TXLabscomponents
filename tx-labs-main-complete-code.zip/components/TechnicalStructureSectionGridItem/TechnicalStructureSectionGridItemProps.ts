import type { TechnicalStructureSectionGridItem } from 'types';

type TechnicalStructureSectionGridItemProps = {
  item: TechnicalStructureSectionGridItem;
  index: number;
};

export default TechnicalStructureSectionGridItemProps;
