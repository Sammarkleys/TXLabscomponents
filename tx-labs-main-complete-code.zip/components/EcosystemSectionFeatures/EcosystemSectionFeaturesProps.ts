type EcosystemSectionFeaturesProps = {
  features: string[];
};

export default EcosystemSectionFeaturesProps;
