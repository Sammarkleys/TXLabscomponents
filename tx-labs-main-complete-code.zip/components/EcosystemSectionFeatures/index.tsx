// @ts-ignore
import Fade from 'react-reveal/Fade';
import type EcosystemSectionFeaturesProps from './EcosystemSectionFeaturesProps';

const EcosystemSectionFeatures = ({
  features,
}: EcosystemSectionFeaturesProps) => (
  <ul className="grid grid-cols-1 gap-8 lg:grid-cols-2">
    {features.map((feature, index) => (
      <Fade key={feature} delay={index * 200}>
        <li className="pl-4 border-l-4 border-white">
          <p className="text-[1.375rem] font-display">{feature}</p>
        </li>
      </Fade>
    ))}
  </ul>
);

export default EcosystemSectionFeatures;
