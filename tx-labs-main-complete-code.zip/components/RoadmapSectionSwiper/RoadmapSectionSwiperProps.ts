import type { RoadmapSectionSwiperSlide } from 'types';

type RoadmapSectionSwiperProps = {
  slides: RoadmapSectionSwiperSlide[];
};

export default RoadmapSectionSwiperProps;
