/* eslint-disable @next/next/no-img-element */
// @ts-ignore
import Fade from 'react-reveal/Fade';
import Section from '../Section';
import TwoColContainer from '../TwoColContainer';
import InformationSwiper from '../InformationSwiper';

const ApplicationsSectionTwo = () => (
  <Section className="bg-center bg-no-repeat bg-cover lg:bg-contain bg-gradient-two">
    <TwoColContainer>
      <img
        className="hidden lg:block"
        src="/svg/applications-section-two-illustration.svg"
        alt="Applications section two illustration"
      />
      <Fade>
        <InformationSwiper
          slides={[
            {
              title:
                'Currently, off-chain applications require developers to build their own node infrastructures individually and repetitively.',
              body: 'These node infrastructures can take up to 6-12 months to build, a huge time and financial commitment compared to that of smart contract based on-chain applications.',
            },
            {
              title:
                'Building off-chain applications can be compared to building on-chain applications without a general-purpose underlying platform like Ethereum.',
              body: 'I.e. Namecoin - a legacy platform mirroring aspects of ENS (Ethereum Name Service) but with a standalone blockchain for its backend.',
            },
            {
              title:
                'The cumbersome nature of developing off-chain applications is hindering the integration between Web2 and Web3 paradigms.',
              body: 'With a more robust off-chain ecosystem utilizing data and resources from both Web2 and Web3 worlds, we will be seeing not only more capable on-chain applications, but also a more cohesive integration between both ecosystems.',
            },
          ]}
        />
      </Fade>
      <img
        className="block lg:hidden"
        src="/svg/applications-section-two-illustration.svg"
        alt="Applications section two illustration"
      />
    </TwoColContainer>
  </Section>
);

export default ApplicationsSectionTwo;
