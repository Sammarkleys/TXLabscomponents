import type { TechnicalStructureSectionGridItem } from 'types';

type TechnicalStructureSectionGridProps = {
  items: TechnicalStructureSectionGridItem[];
};

export default TechnicalStructureSectionGridProps;
