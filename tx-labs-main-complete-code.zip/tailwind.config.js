module.exports = {
  content: ['./pages/**/*.tsx', './components/**/*.tsx'],
  theme: {
    container: {
      center: true,
      padding: '1rem',
    },
    extend: {
      backgroundImage: {
        gradient: "url('/svg/gradient-background.svg')",
        'gradient-two': "url('/svg/gradient-background-two.svg')",
      },
    },
    fontFamily: {
      body: ["'Inter'", 'sans-serif'],
      display: ['PPNeueMachina', 'sans-serif'],
    },
  },
  plugins: [],
};
